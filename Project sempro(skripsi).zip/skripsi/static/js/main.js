const chatBox = document.getElementById("chat-box");

function addBubble(text, type) {
  const chat = document.createElement("div");
  chat.className = `chat ${type}`;
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.innerHTML = text;

  const avatar = document.createElement("img");
  avatar.className = "avatar";

  if (type === "server") {
    avatar.src = "https://cdn-icons-png.flaticon.com/512/4712/4712109.png";
    chat.appendChild(avatar);
    chat.appendChild(bubble);
  } else {
    avatar.src = "https://cdn-icons-png.flaticon.com/512/9131/9131529.png";
    chat.appendChild(bubble);
    chat.appendChild(avatar);
  }

  chatBox.appendChild(chat);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function showTyping() {
  const typingDiv = document.createElement("div");
  typingDiv.className = "chat server typingDiv";
  typingDiv.innerHTML = `
    <img src="https://cdn-icons-png.flaticon.com/512/4712/4712109.png" class="avatar">
    <div class="typing">AES Bot sedang mengetik...</div>
  `;
  chatBox.appendChild(typingDiv);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function removeTyping() {
  const typing = document.querySelector(".typingDiv");
  if (typing) typing.remove();
}

// ✅ Versi baru: ambil data riwayat dari halaman langsung, bukan dari /history
function loadHistory() {
  // cek apakah chatBox sudah punya isi dari Jinja
  if (chatBox.children.length === 0) {
    addBubble("Halo 👋! Saya <b>AES Bot</b>. Ketik pesan lalu tekan <b>Encrypt</b>.", "server");
  } else {
    // kalau sudah ada isi dari index.html, cukup scroll ke bawah
    chatBox.scrollTop = chatBox.scrollHeight;
  }
}

async function encryptMessage() {
  const message = document.getElementById("message").value;
  if (!message.trim()) return alert("Pesan tidak boleh kosong!");
  
  addBubble(message, "user");
  document.getElementById("message").value = "";

  showTyping();

  const res = await fetch("/encrypt", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `message=${encodeURIComponent(message)}`
  });

  const data = await res.json();
  removeTyping();

  if (data.error) {
    addBubble(`<b>Error:</b> ${data.error}`, "server");
  } else {
    addBubble(`
      🔐 <b>Hasil Enkripsi:</b><br>
      <span class="text-sm text-gray-700">Cipher:</span> <code>${data.cipher}</code><br>
      <span class="text-sm text-gray-700">Nonce:</span> <code>${data.nonce}</code><br>
      <span class="text-sm text-gray-700">Key:</span> <code>${data.key}</code>
    `, "server");
  }
}

async function decryptMessage() {
  showTyping();
  const res = await fetch("/decrypt", { method: "POST" });
  const data = await res.json();
  removeTyping();

  if (data.error) {
    addBubble(`<b>Error:</b> ${data.error}`, "server");
  } else {
    addBubble(`💬 <b>Pesan Asli:</b> ${data.plaintext}`, "server");
  }
}

async function clearHistory() {
  if (!confirm("Hapus semua riwayat chat?")) return;
  await fetch("/clear", { method: "POST" });
  chatBox.innerHTML = "";
  addBubble("Riwayat chat telah dihapus. Ketik pesan baru untuk memulai lagi 💬", "server");
}

// Jalankan saat halaman dibuka
loadHistory();
