# =====================================================
# Simulasi Enkripsi & Dekripsi AES + Koneksi Database
# =====================================================

from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
import base64
import mysql.connector

app = Flask(__name__)
app.secret_key = "secret123"  # kunci session

# =====================================================
# Koneksi ke Database MySQL
# =====================================================
def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",          # ubah jika username MySQL kamu beda
        password="",          # isi jika pakai password
        database="flask_chat" # nama database yang sudah dibuat
    )

# =====================================================
# Fungsi Simpan & Ambil Data Chat dari Database
# =====================================================
def save_chat_to_db(role, message):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO chat_history (role, message) VALUES (%s, %s)", (role, message))
        conn.commit()
        cursor.close()
        conn.close()
    except Exception as e:
        print("❌ Gagal menyimpan ke database:", e)

def load_chat_from_db():
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT id, role, message, timestamp FROM chat_history ORDER BY id DESC")
        chats = cursor.fetchall()
        cursor.close()
        conn.close()
        return chats
    except Exception as e:
        print("❌ Gagal memuat data dari database:", e)
        return []

def load_chat_by_id(chat_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM chat_history WHERE id = %s", (chat_id,))
        chat = cursor.fetchone()
        cursor.close()
        conn.close()
        return chat
    except Exception as e:
        print("❌ Gagal memuat data chat:", e)
        return None

def clear_chat_db():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM chat_history")
        conn.commit()
        cursor.close()
        conn.close()
    except Exception as e:
        print("❌ Gagal menghapus data:", e)


# =====================================================
# Key global untuk enkripsi
# =====================================================
key = get_random_bytes(16)
nonce = None
ciphertext = None


# =====================================================
# Fungsi Enkripsi & Dekripsi
# =====================================================
def encrypt_message(data):
    global nonce, ciphertext
    cipher = AES.new(key, AES.MODE_EAX)
    nonce = cipher.nonce
    ciphertext, tag = cipher.encrypt_and_digest(data.encode())

    cipher_b64 = base64.b64encode(ciphertext).decode()
    nonce_b64 = base64.b64encode(nonce).decode()

    return {
        "cipher": cipher_b64,
        "nonce": nonce_b64,
        "key": key.hex(),
    }


def decrypt_message():
    global nonce, ciphertext
    if ciphertext is None or nonce is None:
        return {"error": "Belum ada data terenkripsi untuk didekripsi!"}

    cipher_dec = AES.new(key, AES.MODE_EAX, nonce=nonce)
    plaintext = cipher_dec.decrypt(ciphertext).decode()
    return {"plaintext": plaintext}


# =====================================================
# Halaman Home & Simulasi
# =====================================================
def init_chat():
    if "chat_history" not in session:
        session["chat_history"] = load_chat_from_db()
        session.modified = True


@app.route("/")
def home():
    return render_template("home.html")


# Route utama simulasi
@app.route("/simulasi")
def index():
    init_chat()
    db_history = load_chat_from_db()
    return render_template("index.html", chat_history=session["chat_history"], db_history=db_history)

# Alias agar HTML lama yang pakai url_for('simulasi_page') tetap berfungsi
@app.route("/simulasi_page")
def simulasi_page():
    return redirect(url_for("index"))


# =====================================================
# Halaman Riwayat Chat
# =====================================================
@app.route("/history")
def history_page():
    chats = load_chat_from_db()
    return render_template("history.html", chats=chats)


@app.route("/load_chat/<int:chat_id>")
def load_chat(chat_id):
    chat = load_chat_by_id(chat_id)
    if chat:
        session["chat_history"] = [chat]
        session.modified = True
        return redirect(url_for("index"))
    else:
        return "Chat tidak ditemukan!", 404


# =====================================================
# API: Enkripsi, Dekripsi, History, Clear
# =====================================================
@app.route("/encrypt", methods=["POST"])
def encrypt():
    init_chat()
    message = request.form.get("message", "")
    if not message.strip():
        return jsonify({"error": "Pesan tidak boleh kosong!"})

    # simpan pesan user
    session["chat_history"].append({"type": "user", "text": message})
    save_chat_to_db("user", message)

    # proses enkripsi
    result = encrypt_message(message)
    response_text = (
        f"🔐 <b>Hasil Enkripsi:</b><br>"
        f"<span class='text-sm text-gray-700'>Cipher:</span> <code>{result['cipher']}</code><br>"
        f"<span class='text-sm text-gray-700'>Nonce:</span> <code>{result['nonce']}</code><br>"
        f"<span class='text-sm text-gray-700'>Key:</span> <code>{result['key']}</code>"
    )

    # simpan hasil enkripsi (server)
    session["chat_history"].append({"type": "server", "text": response_text})
    save_chat_to_db("server", response_text)
    session.modified = True

    return jsonify(result)


@app.route("/decrypt", methods=["POST"])
def decrypt():
    init_chat()
    result = decrypt_message()

    if "error" in result:
        response_text = f"<b>Error:</b> {result['error']}"
    else:
        response_text = f"💬 <b>Pesan Asli:</b> {result['plaintext']}"

    session["chat_history"].append({"type": "server", "text": response_text})
    save_chat_to_db("server", response_text)
    session.modified = True

    return jsonify(result)


@app.route("/clear", methods=["POST"])
def clear_chat():
    session["chat_history"] = []
    session.modified = True
    clear_chat_db()
    return jsonify({"status": "cleared"})


# =====================================================
# Jalankan Aplikasi
# =====================================================
if __name__ == "__main__":
    app.run(debug=True)
